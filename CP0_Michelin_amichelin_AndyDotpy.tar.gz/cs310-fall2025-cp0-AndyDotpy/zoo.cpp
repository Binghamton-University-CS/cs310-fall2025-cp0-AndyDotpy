#include <iostream>
#include <stdlib.h>
#include <string>
//#include "Animal.h"
#include "AnimalsInZoo.h"
using namespace std;

int main() {
   Animal *animal1 = new Animal("African Elephant", 1758);
   Animal animal2("Giant Panda", 1869);

   delete animal1;
   animal1 = new Animal("Snow Leopard", 1777);

   AnimalsInZoo animalZoo = AnimalsInZoo();
   animalZoo.display(); // Nothing will be printed here because no animal
   animalZoo = AnimalsInZoo(Animal("Dragon", 2006));
   animalZoo.display(); // Prints the number of animals (1) and the animal as there is a animal
   animalZoo = AnimalsInZoo();
   animalZoo.display(); // Nothing will be printed because AnimalsInZoo() constructor sets numAnimals to 0 

   animal2.display();
   animal1->display();

   delete animal1;
}
