
#ifndef ANIMALS_IN_ZOO
#define ANIMALS_IN_ZOO
#include "Animal.h"
class AnimalsInZoo {
	
	public:
		AnimalsInZoo();
		AnimalsInZoo(Animal newAnimal);
		void display();

	private:
		int numAnimals;
		Animal animal;
};
#endif
