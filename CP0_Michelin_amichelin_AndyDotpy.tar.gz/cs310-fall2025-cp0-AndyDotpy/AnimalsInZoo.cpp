#include "AnimalsInZoo.h"
#include <ostream>

AnimalsInZoo::AnimalsInZoo() {
	numAnimals = 0;
}

AnimalsInZoo::AnimalsInZoo(Animal newAnimal) {
	animal = newAnimal;
	numAnimals = 1;
}

void AnimalsInZoo::display() {
	if (numAnimals) {
		cout << "Num Animals: " << numAnimals << " ";
		animal.display();
	}
}

